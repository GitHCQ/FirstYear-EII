# Modulo con las funciones que utilizaremos para la realizacion del trabajo.
import webbrowser as web

def promedio_de_subida(diccionario,codigo):
    """" Esta función recibe como parametros el código de la estación de la que quieres saber el horario en el que mas gente sube al tren
    y el diccionario en el que se busca ese código, que es donde estan recopilados todos los códigos de las estaciones. La función analiza
    la cantidad de gente que se sube durante todo el día en la estacion indicada y acaba retornando el promedio de gente que se sube en
    cada una de la estaciones"""
    promedio = 0
    iteraciones = 0
    # inicializamos 2 variables locales, la primera para guardar la suma total del promedio y la segunda para contar la cantidad total
    # de veces que pasa un tren por esa estación.
    for linea in diccionario[codigo]:
    # recorremos cada linea del diccionario con el código en cuestión para poder extraer la cantidad de personas.
        promedio = promedio + int(linea[-2])
        # extraemos la cantidad de gente que se sube y la sumamos a la cantidad anterior.
        iteraciones = iteraciones + 1
        # de igual manera sumamos un tren más a la suma total.
    promedio = promedio / iteraciones
    #Calculamos el promedio total, flujo de la suma total de gente que se sube entre el total de veces que pasa algún tren por la estacion.
    return promedio
    # Por último, retornamos el promedio total.

def promedio_de_bajada(diccionario,codigo):
    """" Esta función recibe como parametros el código de la estación de la que quieres saber el horario en el que mas gente sube al tren
    y el diccionario en el que se busca ese código, que es donde estan recopilados todos los códigos de las estaciones. La función analiza
    la cantidad de gente que se baja durante todo el día en la estacion indicada y acaba retornando el promedio de gente que se baja en
    cada una de la estaciones"""
    promedio = 0
    iteraciones = 0
    # inicializamos 2 variables locales, la primera para guardar la suma total del promedio de personas que se bajan y la segunda para contar la cantidad total
    # de veces que pasa un tren por esa estación.
    for linea in diccionario[codigo]:
    # recorremos cada linea del diccionario con el código en cuestión para poder extraer la cantidad de personas.
        promedio = promedio + int(linea[-1])
        # extraemos la cantidad de gente que se baja y la sumamos a la cantidad anterior.
        iteraciones = iteraciones + 1
        # de igual manera sumamos un tren más a la suma total.
    promedio = promedio / iteraciones
    #Calculamos el promedio total, flujo de la suma total de gente que se baja entre el total de veces que pasa algún tren por la estacion.
    return promedio
    # Por último, retornamos el promedio total.

def mayor_afluencia_subidas(diccionario, codigo):
    """ Esta funcion recibe como parametros el codigo de la estacion de la que quieres saber el horario en el que mas gente sube al tren
    y el diccionario en el que se busca ese codigo, que es donde estan recopilados todos los codigos de las estaciones. La funcion analiza
    los pasajeros que se suben en cada hora del dia, y acaba devolviendo el rango horario en el que se suben mas personas en ese estacion."""
    mayor_subida = -1
    # inicializamos el numero mayor de pasajeros que suben en una franja horaria
    horario_mas_concurrido_de_subidas = ""
    # inicializamos una variable para almacenar el horario donde se sube mas gente
    for linea in diccionario[codigo]:
    # recorremos cada linea  con cada franja horaria de la estacion con el codigo introducido
        if int(linea[4]) > mayor_subida:
        # comprobamos que el nuevo numero de pasajeros que se suben sea o no mayor que el maximo que ya estaba almacenado
            mayor_subida = int(linea[4])
            # si era mayor, atribuimos a la varianle mayor_subida ese valor que sera el numero mayor de pasajeros subidos
            horario_mas_concurrido_de_subidas = linea[3]
            # atribuimos a esta variable la franja horaria correspondiente, ya que ahora en ese hora es cuando mas gente se ha subido
    return horario_mas_concurrido_de_subidas
    # devolvemos finalmente la franja horaria donde mas gente se haya subido

def mayor_afluencia_bajadas(diccionario, codigo):
    """ Esta funcion recibe como parametros el codigo de la estacion de la que quieres saber el horario en el que mas gente baja del tren
    y el diccionario en el que se busca ese codigo, lugar donde estan recopilados todos los codigos de las estaciones. La funcion analiza
    los pasajeros que se bajan en cada hora del dia, y acaba devolviendo el rango horario en el que se bajan mas personas en ese estacion."""
    mayor_bajada = -1
    # inicializamos el numero mayor de pasajeros que bajan en una franja horaria
    horario_mas_concurrido_de_bajadas = ""
    # inicializamos una variable para almacenar el horario donde se baja mas gente
    for linea in diccionario[codigo]:
    # recorremos cada linea  con cada franja horaria de la estacion con el codigo introducido
        if int(linea[-1]) > mayor_bajada:
        # comprobamos que el nuevo numero de pasajeros que se bajan sea o no mayor que el maximo que ya estaba almacenado
            mayor_bajada = int(linea[-1])
            # si era mayor, atribuimos a la varianle mayor_bajada ese valor que sera el numero mayor de pasajeros bajadas
            horario_mas_concurrido_de_bajadas = linea[3]
            # atribuimos a esta variable la franja horaria correspondiente, ya que ahora en ese hora es cuando mas gente se ha bajado
    return horario_mas_concurrido_de_bajadas
    # devolvemos finalmente la franja horaria donde mas gente se haya bajado

def mostrar_estaciones(datos):
    """ Funcion que muestra por pantalla el nombre de cada estación junto a su codigo, para que el usuario pueda seleccionar el que desee"""
    # Recorremos cada linea de los datos
    for linea in datos:
        # Separamos la linea en función de ';'
        linea = linea.strip().split(";")
        # Lo mostramos con un print con formato, que alinea el nombre de la estación a la izquierda y rellena con '.' hasta llegar a 30 espacios.
        # seguido de el código de dicha estación.
        print(f"{linea[1]:.<30}{linea[0]}")

def abrir_enlace(codigo,datos):
    """ Función que, dado un código de estación válido, te dirige a su página web y devuelve True, si no, False"""
    for linea in datos:
        linea = linea.strip().split(";")
        if linea[0] == str(codigo):
            # Si el primer elemento de la linea coincide con el código introducido, abrimos la página y devolvemos True.
            web.open(linea[-1])
            return True
    # Si no se ha encontrado ningún código que coincida, devuelve False.
    return False
