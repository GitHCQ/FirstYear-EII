# Grupo 1:
# Juan Losada Pérez uo302850
# Hugo Carbajajales Quintana uo300051
# Adrian Gutiérrez García uo300627
# Fernando José Remis Figueroa uo302109

# Importamos las funciones creadas del modulo de python
from funciones import *

# Abrimos el fichero que contiene los datos a procesar.
fichero = open("ficheros/pasajeros_cercanias_asturias.csv")
# Leemos el fichero con la funcion readlines() para crear una lista en la que cada elemento es una linea del archivo.
datos = fichero.readlines()
# Cerramos el archivo y empezamos a procesar los datos.
fichero.close()

# Inicializamos un diccionario, en el que cada elemento será una lista con las lineas con dicho codigo de estación.
# La clave para acceder a ese elemento será el código común de cada estación.
estaciones = {}

# Aqui formamos el diccionario de la forma descrita.
for linea in datos:
    # Con la función strip eliminamos los '\n'
    linea = linea.strip()
    # Con la función split() dividimos el string en substrings en función del ';'
    linea = linea.split(";")
    # Damos al código el valor de el primer elemento de la lista. Será la clave para acceder a dicho conjunto.
    codigo = linea[0]
    # Si la clave o cogigo ya ha sido introducido en el diccionario, le añadimos esta lista. 
    if codigo in estaciones:
        estaciones[codigo].append(linea)
    # Si no existe esa clave en el diccionario, creamos una lista para dicha clave con el la linea en cuestion.
    else:
        estaciones[codigo] = [linea]

# Ahora recorreremos todas los elementos del diccionario y mostraremos los resultados en un nuevo fichero generado.
# Creamos el nuevo fichero:
resultado = open("ficheros/resultado.txt","w")
# Imprimiremos una primera linea en el documento que hará de índice para los datos que se imprimirán a continuación.
print("Estación"+20*"."+"Intervalo con mas subidas","Intervalo con menos subidas","Promedio personas subidas","Promedio personas bajadas\n\n",
      sep="...",file=resultado)
# Recorremos cada elemento del diccionario:
for codigo in estaciones:
    # Ejecutamos las funciones del archivo funciones y escribiremos los datos procesados en el fichero creado.
    nombre = estaciones[codigo][0][1].replace('Ã‘','Ñ')
    # Creamos variables para los resultados de las funciones. 
    i_subidas,i_bajadas = mayor_afluencia_subidas(estaciones, codigo), mayor_afluencia_bajadas(estaciones, codigo)
    p_subidas,p_bajadas = promedio_de_subida(estaciones,codigo), promedio_de_bajada(estaciones,codigo)
    # Imprimimos en el fichero final los datos procesados mediante la funcion write y f-strings.
    resultado.write(f"{estaciones[codigo][0][1].replace('Ã‘','Ñ'):.<27}")
    resultado.write(f"{i_subidas:.^27}{i_bajadas:.^28}{p_subidas:.^30.3f}{p_bajadas:.>16.3f}")
    resultado.write("\n")
# Una vez todo impreso cerramos el fichero.
resultado.close()

# Indicamos al usuario que se han creado datos en el fichero.
print("Se han generado datos de interes en el fichero 'resultado.txt'")

# Por último preguntaremos al usuario si quiere acceder a los datos técnicos de alguna estación en la web de renfe.
opcion = input("¿Desea acceder a las características de alguna estación? (si/no):")
# Si el usuario introduce "si", le mostraremos una lista con le nombre de todas las estaciones disponibles junto a su codigo.
if opcion.lower() == "si":
    # Abrimos el fichero que contiene el listado de esraciones junto a sus enlaces.
    fichero = open("ficheros/listado_estaciones_cercanias.csv")
    datos = fichero.readlines()
    fichero.close()
    mostrar_estaciones(datos)
    while not abrir_enlace(input("Introduzca el codigo que desee: "),datos):
        print("Debe introducir un código válido")

# Finaliza el programa y lo indicamos.
print("Programa finalizado")


