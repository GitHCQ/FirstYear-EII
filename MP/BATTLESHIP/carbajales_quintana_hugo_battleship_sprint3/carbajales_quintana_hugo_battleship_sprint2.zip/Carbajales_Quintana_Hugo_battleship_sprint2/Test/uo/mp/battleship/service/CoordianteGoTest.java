package uo.mp.battleship.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.Direction;

import static org.junit.Assert.assertEquals;

	public class CoordianteGoTest {
	    
	    // Test moving west from column A
	    @Test
	    public void testGoWestFromColumnA() {
	        Coordinate initialCoord = new Coordinate(0, 0);
	        Coordinate resultCoord = initialCoord.go(Direction.WEST);
	        assertEquals(new Coordinate(-1, 0), resultCoord);
	    }
	    
	    // Test moving north from row 0
	    @Test
	    public void testGoNorthFromRow0() {
	        Coordinate initialCoord = new Coordinate(1, 0);
	        Coordinate resultCoord = initialCoord.go(Direction.NORTH);
	        assertEquals(new Coordinate(1, 1), resultCoord);
	    }
	    
	    // Test moving in all directions from a coordinate not at row 0 or column 0
	    @Test
	    public void testGoAllDirectionsFromNonZeroCoordinate() {
	        Coordinate initialCoord = new Coordinate(2, 3);
	        
	        Coordinate resultNorth = initialCoord.go(Direction.NORTH);
	        assertEquals(new Coordinate(2, 4), resultNorth);
	        
	        Coordinate resultSouth = initialCoord.go(Direction.SOUTH);
	        assertEquals(new Coordinate(2, 2), resultSouth);
	        
	        Coordinate resultEast = initialCoord.go(Direction.EAST);
	        assertEquals(new Coordinate(3, 3), resultEast);
	        
	        Coordinate resultWest = initialCoord.go(Direction.WEST);
	        assertEquals(new Coordinate(1, 3), resultWest);
	    }
	}

