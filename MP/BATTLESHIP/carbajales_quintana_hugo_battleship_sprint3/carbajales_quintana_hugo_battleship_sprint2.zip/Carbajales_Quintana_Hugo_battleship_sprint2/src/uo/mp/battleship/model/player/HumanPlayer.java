package uo.mp.battleship.model.player;

import uo.mp.battleship.interaction.ConsoleReader;
import uo.mp.battleship.model.board.Coordinate;

public class HumanPlayer extends Player {
    private ConsoleReader consoleReader;

    public HumanPlayer(String name) {
        super(name);
        this.consoleReader = new ConsoleReader();
    }

    @Override
    public Coordinate makeChoice() {
        Coordinate choice;
        do {
            choice = consoleReader.readCoordinates();
        } while (shotCoordinates.contains(choice));

        shotCoordinates.add(choice);
        return choice;
    }
}
