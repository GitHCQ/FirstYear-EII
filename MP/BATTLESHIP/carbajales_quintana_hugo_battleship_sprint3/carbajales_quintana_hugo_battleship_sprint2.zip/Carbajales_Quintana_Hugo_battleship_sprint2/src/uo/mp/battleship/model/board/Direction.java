package uo.mp.battleship.model.board;

public enum Direction {
	NORTH,
	EAST,
	WEST,
	SOUTH,

}
