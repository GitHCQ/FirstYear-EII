package uo.mp.battleship.model.player;
import uo.mp.battleship.model.board.Coordinate;
import java.util.Random;

public class ComputerPlayer extends Player {
    public ComputerPlayer(String name) {
        super(name);
    }

    @Override
    public Coordinate makeChoice() {
        Coordinate choice;
        do {
            choice = generateRandomCoordinate();
        } while (shotCoordinates.contains(choice));
        shotCoordinates.add(choice);
        return choice;
    }
    
    
    private Coordinate generateRandomCoordinate() {
        if (myOpponentShips == null) {
            throw new IllegalStateException("myOpponentShips cannot be null.");
        }

        Random random = new Random();
        int x = random.nextInt(myOpponentShips.getSize());
        int y = random.nextInt(myOpponentShips.getSize());
        return new Coordinate(x, y);
    }
   
}

