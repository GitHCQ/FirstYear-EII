package uo.mp.battleship.model.game;

import uo.mp.battleship.interaction.ConsoleReader;
import uo.mp.battleship.interaction.ConsoleWriter;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.Damage;
import uo.mp.battleship.model.player.ComputerPlayer;
import uo.mp.battleship.model.player.HumanPlayer;
import uo.mp.battleship.model.player.Player;

public class Game {
	private Player humanPlayer;
    private Player computerPlayer;
    private TurnSelector currentPlayer;
    private Board humanBoard;
    private Board computerBoard;
	private boolean debugMode=false;
	private ConsoleWriter presenter;
	private ConsoleReader reader;
	
	/**
	 * @param human
	 * @param computer
	 * @param size
	 */
	public Game(HumanPlayer human, ComputerPlayer computer, int size) {
	    if (size < 11 || size > 20) {
	        throw new RuntimeException("El tablero debe tener tamaño entre 10 y 20");
	    }

	    this.humanPlayer = human;
	    this.computerPlayer = computer;
	    humanBoard = new Board(size);
	    computerBoard = new Board(size);
	    currentPlayer = new TurnSelector(human, computer);
	    computerPlayer.setOpponentShips(humanBoard);
	    humanPlayer.setOpponentShips(computerBoard);
	    presenter = createPresenter();
	    reader = createReader();
	}


	public Game(HumanPlayer leftPlayer, ComputerPlayer rightPlayer) {
	        asignPlayers(leftPlayer, rightPlayer);
	        humanBoard = new Board(10);
	        computerBoard = new Board(10);
	        currentPlayer = new TurnSelector(leftPlayer, rightPlayer);
	        computerPlayer.setOpponentShips(humanBoard);
		    humanPlayer.setOpponentShips(computerBoard);
	        presenter = createPresenter();
	        reader = createReader();
	        turnSelector(currentPlayer, leftPlayer, rightPlayer);
	    }
	    
	public void setDebugMode ( boolean gameMode ) {
		debugMode=gameMode;
	}

	public void play() {
		Player current;
	    	do {
	        // Se muestran los tableros
	        presenter.showGameStatus(humanBoard, computerBoard, debugMode);
	        // Selecciona turno
	        current = currentPlayer.next();
	        // Se muestra el jugador
	        presenter.showTurn(current.getName());
	        // Se elige el tiro
	        Coordinate pos = current.makeChoice();
	        pos = new Coordinate(pos.getCol(), pos.getRow());
	        // Muestra el disparo
	        presenter.showShootingAt(pos);
	        Damage disparo = current.shootAt(pos);
	        // Muestra el mensaje del disparo
	        presenter.showShotMessage(disparo);
	        if (disparo.equals(Damage.SEVERE_DAMAGE) || disparo.equals(Damage.MASSIVE_DAMAGE)) {
	            currentPlayer.repeat();
	        }
	        
	    } while (!humanPlayer.hasWon() && !computerPlayer.hasWon());
	    	presenter.showWinner(current.getName());
	}
	
	private void asignPlayers(HumanPlayer leftPlayer, ComputerPlayer rightPlayer) {
		// Asigno los jugadores
        this.humanPlayer = leftPlayer;
        this.computerPlayer = rightPlayer;
	}
	
	private ConsoleWriter createPresenter() {
		return new ConsoleWriter();
	}
	private ConsoleReader createReader() {
	    return new ConsoleReader();
	}
	private void turnSelector(TurnSelector tl,Player human,Player computer) {
		tl=new TurnSelector(human,computer);
	}
	}