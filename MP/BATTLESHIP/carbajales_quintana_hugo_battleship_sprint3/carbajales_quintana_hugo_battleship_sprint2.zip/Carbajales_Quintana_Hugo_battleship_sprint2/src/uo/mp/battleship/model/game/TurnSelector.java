package uo.mp.battleship.model.game;

import java.util.Random;

import uo.mp.battleship.model.player.Player;
import uo.mp.util.check.ArgumentChecks;

public class TurnSelector {
	private Player currentPlayer;
	private Player user;
	private Player computer;
	
	public TurnSelector(Player user,Player computer) {
		ArgumentChecks.isNotNull(computer);
		ArgumentChecks.isNotNull(user);
		this.user=user;
		this.computer=computer;
		inicializeTurn();
		
	}
	/**
	 * La primera vez el jugador se seleccionara aleatoriamente,este metodo hará alternancia de jugadores
	 * salvo que se haya ejecutado anteriormente el metodo repeat()
	 * @return
	 */
	public Player next() {
		if(currentPlayer.equals(computer) ||  computer.hasHit()) {
			this.currentPlayer=user;
		}else {
			this.currentPlayer=computer;
		}
		return currentPlayer;
	    
	    
	}
	public void repeat() {
		next();
		
	}
	private Player inicializeTurn() {
		Random r =new Random();
		if(r.nextBoolean()) {
			currentPlayer=user;
		}else {
			currentPlayer=computer;
		}
		return currentPlayer;
	}
	
}

