package uo.mp.battleship.model.player;

import java.util.HashSet;
import java.util.Set;

import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.Damage;

public abstract class Player {
	private String name;
	protected Board myShips;
	protected Board myOpponentShips;
	protected Set<Coordinate> shotCoordinates;
	private boolean hasHit;
	

	public Player(String name) {
			if (name == null || name.isEmpty()) {
	            this.name = "user";
			} else {
	            this.name = name;
			}
			 this.shotCoordinates = new HashSet<Coordinate>(); // Agrega esta línea para inicializar shotCoordinates
			 this.hasHit=false;
		}


	    public String getName() {
	        return this.name;
	    }

	    public void setMyShips(Board board) {
	        this.myShips = board;
	    }

	    public void setOpponentShips(Board board) {
	        this.myOpponentShips = board;
	    }

	    public Damage shootAt(Coordinate position) {
	        if (shotCoordinates.contains(position)) {
	            return Damage.NO_DAMAGE;
	        }

	        Damage damage = myOpponentShips.shootAt(position);
	        if (damage != Damage.NO_DAMAGE) {
	            shotCoordinates.add(position);
	            this.hasHit=true;
	        }
	        return damage;
	    }

	    public Board getMyShips() {
	        return myShips;
	    }

	    protected Board getOpponentShips() {
	        return myOpponentShips;
	    }

	    public boolean hasWon() {
	        return myOpponentShips.isFleetSunk();
	    }

	    public abstract Coordinate makeChoice();
	    
	    protected boolean contains(Coordinate coordinate) {
	        return shotCoordinates.contains(coordinate);
	    }
	    public boolean hasHit() {
	    	return this.hasHit;
	    }
	    

	}

