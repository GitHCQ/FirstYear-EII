package uo.mp.battleship.console;

import java.util.ArrayList;
import java.util.List;

import uo.mp.battleship.interaction.GameInteractor;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.util.console.Console;

public class ConsoleGameInteractor implements GameInteractor{
	private List<Coordinate> shotCoordinates = new ArrayList<>();

	@Override
    public Coordinate getTarget() {
        Coordinate choice;
        do {
            choice = readCoordinate();
        } while (shotCoordinates.contains(choice));
        shotCoordinates.add(choice);
        return choice;
    }

    private Coordinate readCoordinate() {
        int x = Console.readInt("Enter column (0-9): ");
        int y = Console.readInt("Enter row (0-9): ");
        return new Coordinate(x, y);
    }


	
}
