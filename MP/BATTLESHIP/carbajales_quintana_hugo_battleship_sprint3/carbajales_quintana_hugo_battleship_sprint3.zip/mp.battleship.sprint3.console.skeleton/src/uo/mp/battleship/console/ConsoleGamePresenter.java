package uo.mp.battleship.console;

import uo.mp.battleship.interaction.GamePresenter;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.squares.Damage;
import uo.mp.battleship.model.player.Player;

public class ConsoleGamePresenter implements GamePresenter{

	@Override
	public void showGameStatus(Board left, Board right, boolean gameMode) {
		if (gameMode) {
	        // Mostrar encabezados de ambos tableros
	        System.out.print("     My ships                              Opponent ships\n");
	        System.out.print("     A  B  C  D  E  F  G  H  I  J           A  B  C  D  E  F  G  H  I  J\n");

	        // Mostrar ambas filas de los tableros
	        for (int i = 0; i < left.getSize(); i++) {
	            System.out.print(String.format("%2d", (i + 1)) + " |");

	            // Mostrar tablero del usuario a la izquierda
	            for (int j = 0; j < left.getSize(); j++) {
	                System.out.print(" " + left.getFullStatus()[i][j] + "|");
	            }

	            System.out.print("      ");  // Espacio entre los tableros

	            // Mostrar número de fila y tablero de la máquina a la derecha
	            System.out.print(String.format("%2d", (i + 1)) + " |");
	            for (int j = 0; j < right.getSize(); j++) {
	                System.out.print(" " + right.getFullStatus()[i][j] + "|");
	            }

	            System.out.println();  // Nueva línea después de cada fila
	        }
	    } else {
	        // Mostrar solo el tablero del oponente (computadora)
	    	 System.out.print("      My ships                         Opponent ships\n");
		        System.out.print("     A  B  C  D  E  F  G  H  I  J           A  B  C  D  E  F  G  H  I  J\n");

	        for (int i = 0; i < left.getSize(); i++) {
	            System.out.print(String.format("%2d", (i + 1)) + " |");
	         // Mostrar tablero del usuario a la izquierda
	            for (int j = 0; j < left.getSize(); j++) {
	                System.out.print(" " + left.getFullStatus()[i][j] + "|");
	            }

	            System.out.print("      ");  // Espacio entre los tableros
	            System.out.print(String.format("%2d", (i + 1)) + " |");
	            // Mostrar tablero de la máquina con disparos del jugador
	            for (int j = 0; j < right.getSize(); j++) {
	                if (right.getFullStatus()[i][j] == '*') {
	                    System.out.print(" " + right.getFullStatus()[i][j] + "|");
	                } else if (right.getFullStatus()[i][j] == '\u00F8') {
	                    System.out.print(" " + right.getFullStatus()[i][j] + "|");
	                } else {
	                    System.out.print(" " + " " + "|");
	                }
	            }

	            System.out.println();  // Nueva línea después de cada fila
	        }
	    }
	}	

	@Override
	public void showGameOver() {
		System.out.print("The game is over!!");
		
	}

	@Override
	public void showWinner(Player theWinner) {
		System.out.print("The winner is..."+theWinner.getName());
		
	}

	@Override
	public void showShotMessage(Damage impact) {
		if(impact.equals(Damage.SEVERE_DAMAGE)) {
			System.out.println("HIT!Continue");
		}
		else if(impact.equals(Damage.MASSIVE_DAMAGE)){
			System.out.println("Hit and Sunk!");
		}
		else {
			System.out.println("Miss!Change turn");
		}
}
	@Override
	public void showTurn(Player player) {
		System.out.println("Now the turn is for the player "+player.getName());
		
	}

	@Override
	public void showShootingAt(Coordinate coordinate) {
		char columnChar = (char) ('A' + coordinate.getCol()); 
	    int rowNumber = coordinate.getRow() + 1; 

	    System.out.println("Shooting at " + columnChar + rowNumber);
	}

}
