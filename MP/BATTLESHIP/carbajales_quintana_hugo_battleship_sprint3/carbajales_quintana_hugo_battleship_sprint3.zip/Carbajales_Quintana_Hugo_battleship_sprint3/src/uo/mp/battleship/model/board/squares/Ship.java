package uo.mp.battleship.model.board.squares;

public class Ship implements Target{
	private int size;
	private int shootCount;
	
	public Ship(int shipSize) {
		if (shipSize < 1 || shipSize > 4) {
            throw new IllegalArgumentException("El tamaño del barco debe estar entre 1 y 4 posiciones.");
        }
        this.size = shipSize;
        this.shootCount = 0;
	}
	
	/**
	 * El barco es golpeado por un disparo del oponente
	 * @return devuelve el daño causado (SEVERE_DAMAGE,o MASSIVE_DAMAGE)
	 */
	 public Damage shootAt()   {
	        shootCount++;
	        if (this.shootCount >= size()) {
	            return Damage.MASSIVE_DAMAGE;
	        }
	        return Damage.SEVERE_DAMAGE;
	    }

	/**
	 * @return numero de casillas que ocupa el barco.
	 */
	public int size() {
		return this.size;
	}
	/**
	 * 
	 * @return true si todas las posiciones del barco han sido tocadas (golpeadas), es decir, si el barco 
	 * está hundido; false en caso contrario
	 */
	public boolean isSunk() {
		if(shootCount>=size()) {
			return true;
		}
		return false;
	}
	/**
	 * @return el carácter correspondiente al barco (en función del tamaño que tenga)
	 */
	public char toChar() {
		switch(size()) {
		case 1:
			return 'S';
		case 2:
			return'D';
		case 3:
			return 'C';
		case 4:
			return 'B';
		default:
			return '!';
		}
	}
	/**
	 * @return Devuelve el carácter correspondiente a un disparo tocado (‘*’) o hundido (‘#’).
	 */
	public char toFiredChar() {
		if(shootCount>=size()) {
			return '#';
		}
		return '*';
	}
	public int getShootCount() {
		return this.shootCount;
	}
	
	
}
