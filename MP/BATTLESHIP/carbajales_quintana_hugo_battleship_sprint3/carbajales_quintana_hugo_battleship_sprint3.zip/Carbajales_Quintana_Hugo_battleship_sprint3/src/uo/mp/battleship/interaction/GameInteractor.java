package uo.mp.battleship.interaction;

import uo.mp.battleship.model.board.Coordinate;

public interface GameInteractor {
	Coordinate getTarget() ;
}
