package uo.mp.battleship.model.board.squares;

public interface Target {
	 Damage shootAt();
	 char toChar();
	 char toFiredChar();
}

