package uo.mp.battleship.model.board.squares;

public enum Damage {
	    NO_DAMAGE,      // No hay daño
	    SEVERE_DAMAGE,  // Daño severo
	    MASSIVE_DAMAGE   // Daño masivo
	}

