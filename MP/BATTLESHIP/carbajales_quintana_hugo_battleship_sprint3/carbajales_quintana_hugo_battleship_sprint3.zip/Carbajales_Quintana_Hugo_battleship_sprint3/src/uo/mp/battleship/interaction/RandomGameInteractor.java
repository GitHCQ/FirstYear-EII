package uo.mp.battleship.interaction;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import uo.mp.battleship.model.board.Coordinate;

public class RandomGameInteractor implements GameInteractor{

	 private int boardSize;
	 private List<Coordinate> shotCoordinates;

	    public RandomGameInteractor(int boardSize) {
	        this.boardSize = boardSize;
	        this.shotCoordinates = new ArrayList<Coordinate>();
	    }
	    /**
	     * Devuelve las coordenadas del objetivo elegido tanto por la maquina como
	     * por la persona
	     * @return la coordenada
	     */
	    public Coordinate getTarget() {
	        Coordinate choice;
	        do {
	            choice = generateRandomCoordinate();
	        } while (shotCoordinates.contains(choice));
	        shotCoordinates.add(choice);
	        return choice;
	    }

	    private Coordinate generateRandomCoordinate() {
	        Random random = new Random();
	        int x = random.nextInt(boardSize);
	        int y = random.nextInt(boardSize);
	        return new Coordinate(x, y);
	    }


}
