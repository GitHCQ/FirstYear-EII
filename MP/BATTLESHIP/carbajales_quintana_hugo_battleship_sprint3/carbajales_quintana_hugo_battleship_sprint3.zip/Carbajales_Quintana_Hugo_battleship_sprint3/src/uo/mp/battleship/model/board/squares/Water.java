package uo.mp.battleship.model.board.squares;

public class Water implements Target {
	/**
	 * Como no es un barco, no se refiere al daño. 
	 * @return	NO_DAMAGE
	 */
	public Damage shootAt() {
		return Damage.NO_DAMAGE;
	}
	/**
	 * @return	Devuelve el carácter asociado con una celda Water (‘ϕ’)
	 */
	public char toChar() {
		return ' ';
	}
	/**
	 * 
	 * @return Devuelve el carácter asociado a un disparo perdido.
	 */
	public char toFiredChar() {
		return '\u00F8';
	}
	
	
	
	

}
