package uo.mp.battleship.model.board;

import java.util.List;

import uo.mp.battleship.model.board.squares.Ship;
import uo.mp.battleship.model.board.squares.Water;
class BoardBuilder {
	
static Square[][] build(int size, List<Ship> fleet) {
	Square[][] board = new Square[size][size];
	for (int i = 0; i < size; i += 1) {
        for (int j = 0; j < size; j += 1) {
            if (board[i][j] == null) {
            	board[i][j] = new Square(new Water());  // Agrega agua si la posición no tiene un barco
            }
        }
    }
	board[0][0]=new Square(fleet.get(0));
	
	  board[0][2]=new Square(fleet.get(1)); board[0][4]=new Square(fleet.get(2));
	  board[0][6]=new Square(fleet.get(3));
	  
	  board[2][0]=new Square(fleet.get(4)); board[2][1]=new Square(fleet.get(4));
	  
	  board[2][3]=new Square(fleet.get(5)); board[2][4]=new Square(fleet.get(5));
	  
	  board[2][6]=new Square(fleet.get(6)); board[2][7]=new Square(fleet.get(6));
	  
	  
	  board[4][4]=new Square(fleet.get(7)); board[4][5]=new Square(fleet.get(7));
	  board[4][6]=new Square(fleet.get(7));
	  
	  board[4][0]=new Square(fleet.get(8)); board[4][1]=new Square(fleet.get(8));
	  board[4][2]=new Square(fleet.get(8));
	  
	  board[6][2]=new Square(fleet.get(9)); board[6][3]=new Square(fleet.get(9));
	  board[6][4]=new Square(fleet.get(9)); board[6][5]=new Square(fleet.get(9));
	 
	return board;
	        
	        
	}
	}