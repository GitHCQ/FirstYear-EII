package uo.mp.battleship.model.board;

import uo.mp.battleship.model.board.squares.Direction;

public class Coordinate {
	private int x;
	private int y;
		
	public Coordinate(int col, int row) {
		this.x=col;
		this.y=row;
	}

	public int getCol() {
		return x;
	}

	public int getRow() {
		return y;
	}
	
	@Override
	public String toString() {
		return "Coordenada [ x = " + x + ", y = " + y + " ]";
	}

	public String toUserString() {
		 char columnChar = (char) ('A' + x); 
	     return columnChar + "-" + (y+1);
	    }
	/**
	 * Dada una direccion se avanza una casilla en esa direccion.
	 * @param direction
	 * @return la nueva direccion avanzada 
	 */
	public Coordinate go(Direction direction) {
		int x=getCol();
		int y=getRow();
		switch(direction) {
		  case NORTH:
			  return new Coordinate(x,y+1);
		  case SOUTH:
			  return new Coordinate(x,y-1);
		  case EAST:
			  return new Coordinate(x+1,y);
		  case WEST:
			  return new Coordinate(x-1,y);
	      default:
	    	  return new Coordinate(x,y);
		}
		
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Coordinate other = (Coordinate) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}
	
}
