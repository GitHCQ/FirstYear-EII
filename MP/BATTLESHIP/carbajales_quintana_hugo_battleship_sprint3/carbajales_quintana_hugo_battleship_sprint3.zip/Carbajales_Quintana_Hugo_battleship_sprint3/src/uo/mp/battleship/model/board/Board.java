package uo.mp.battleship.model.board;
import java.util.ArrayList;
import java.util.List;

import uo.mp.battleship.model.board.squares.Damage;
import uo.mp.battleship.model.board.squares.Ship;

public class Board {
	private Square [][]  grid;
	
	public Board( int size ) {
		 List<Ship>fleet=new ArrayList<Ship>(); 
		 fleet.add(new Ship(1)); 
		 fleet.add(new Ship(1));
		 fleet.add(new Ship(1));
		 fleet.add(new Ship(1));
		 fleet.add(new Ship(2));
		 fleet.add(new Ship(2)); 
		 fleet.add(new Ship(2)); 
		 fleet.add(new Ship(3)); 
		 fleet.add(new Ship(3)); 
		 fleet.add(new Ship(4));
		 this.grid = BoardBuilder.build(size,fleet);

	}
	/**
	 * Constructor usado unicamente para las pruebas
	 * @param arg
	 */
	protected Board (Square [][] arg) {
		this.grid=arg;
	}
	/**
	 * Almacena un disparo en la casilla y devuelve el daño.
	 * @param position
	 * @return el daño
	 */
	public Damage shootAt(Coordinate position) {
		 int x = position.getCol();
	     int y = position.getRow();
	     return grid[y][x].shootAt();
	}	
	/**
	 * Metodo que comprueba que tida la flota este hundida
	 * @return false, si la flota no está hundida, true, si es el caso contrario.
	 */
	public boolean isFleetSunk() {
		for(int i=0;i<grid.length;i++) {
			for(int j=0;j<grid[i].length;j++) {
				if(grid[i][j].getTarget() instanceof Ship){
					Ship content=(Ship)grid[i][j].getTarget();
					if(content.size()>content.getShootCount())
						return false;
				}
			}
		}
		return true;
	}
	
	
	public int getSize() {
		return grid.length;
	}
	/**
	 * Devuelve el caracter indentificativo a cada elemento square
	 * @return caracter identificativo
	 */ 
	public char[][] getFullStatus() {
		char [][] status=new char[grid.length][grid[0].length];
		for(int i=0;i<grid.length;i++) {
			for(int j=0;j<grid[i].length;j++) {
				status[i][j]=grid[i][j].toChar();
			}
		}
		return status;
	}
	/**
	 * Devuelve el estado identificativo a cada elemento square o un espacio en blanco
	 * @return
	 */
	public char[][] getMinimalStatus() {
		char [][] status=new char[grid.length][grid[0].length];
		for(int i=0;i<grid.length;i++) {
			for(int j=0;j<grid[i].length;j++) {
				if(grid[i][j].isShot()) {
					status[i][j]=grid[i][j].toChar();
				}
				else {
					status[i][j]=' ';
				}
			}
		}
		return status;
		
	}
	public Square[][] getInnerArray() {
	    Square[][] clone = new Square[grid.length][];
	    for (int i = 0; i < grid.length; i++) {
	        clone[i] = grid[i].clone();
	    }
	    return clone;
	}
	public ArrayList<Coordinate>getNoFiredCoordinates(){
		ArrayList<Coordinate>noFired=new ArrayList<Coordinate>();
		for(int i=0;i<grid.length;i++) {
			for(int j=0;j<grid[i].length;j++) {
				if(!grid[i][j].isShot()) {
					noFired.add(new Coordinate(j,i));
				}
			}
		}
		return noFired;
	}
	/**
	 * Dado un tablero de square se hace una copia al tablero.
	 * @param boardForTest
	 */
	public void setSquares(Square[][] boardForTest) {
	    for (int i = 0; i < grid.length; i++) {
	        for (int j = 0; j < grid[i].length; j++) {
	            grid[i][j] = boardForTest[i][j];
	        }
	    }
	}

}
