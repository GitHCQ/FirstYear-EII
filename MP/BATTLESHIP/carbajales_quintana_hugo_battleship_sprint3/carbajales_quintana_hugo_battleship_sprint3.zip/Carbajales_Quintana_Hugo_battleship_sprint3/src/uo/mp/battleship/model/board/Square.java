package uo.mp.battleship.model.board;

import uo.mp.battleship.model.board.squares.Damage;
import uo.mp.battleship.model.board.squares.Ship;
import uo.mp.battleship.model.board.squares.Target;
import uo.mp.battleship.model.board.squares.Water;

public class Square {
	private Target target;
	private boolean isShot;
	
	 // Constructor original
    public Square() {
        this.target = null;
    }
	public Square (Target target) {
		this.target=target;
		this.isShot=false;
	}
	/**
	 * Marca esta casilla como disparada y propaga el disparo (delega) al barco o al agua referenciada 
	 * por esta casilla.
	 * @return	un enumerado Damage, dependiendo del daño causado por el disparo
	 */
	public Damage shootAt() {
	    if (!isShot) {
	        isShot = true;
	        if (target != null) {
	            return target.shootAt();
	        }
	    }
	    return Damage.NO_DAMAGE;
	}

	/**
	 * Si la casilla ha sido disparada:
	 * @return true
	 */
	public boolean isShot() {
		return isShot;
	}
	/**
	 * 
	 * @return caracter correspondiente al contenido(Un ship o water).Dependerá de si 
	 * la casilla esta disparada o no; si lo está disparo perdido,tocado o hundido; si no esta
	 * devolvera el caracter correspondiente al barco.
	 */
	public char toChar() {
	    if (target != null) {
	        if (isShot) {
	            return target.toFiredChar();
	        } else {
	            return target.toChar();
	        }
	    } else {
	        // Manejo de caso cuando target es null
	        return ' ';  // O el carácter que desees en este caso
	    }
	}
	/**
	 * Guarda en el atributo content de la casilla el obj recibido como paramentro
	 * @param obj ship o water
	 * @return la casilla
	 */
	public Square setContent(Target obj) {
		this.target=obj;
		return this;
	}
	
	/**
	 * @return devuelve true si el contenido de la casilla está asignado a un objeto
	 * Ship o Water, false en otro caso,
	 */
	public boolean hasContent() {
		return target instanceof Ship || target instanceof Water;
	}
	protected Target getTarget() {
		return this.target;
	}

}
