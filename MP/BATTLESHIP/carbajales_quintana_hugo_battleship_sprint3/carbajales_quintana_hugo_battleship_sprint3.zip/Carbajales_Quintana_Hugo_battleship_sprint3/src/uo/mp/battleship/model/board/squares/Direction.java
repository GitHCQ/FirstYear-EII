package uo.mp.battleship.model.board.squares;

public enum Direction {
	NORTH,
	EAST,
	WEST,
	SOUTH,

}
