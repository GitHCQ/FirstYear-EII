package uo.mp.battleship.service;

import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Test;

import uo.mp.battleship.model.game.TurnSelector;
import uo.mp.battleship.model.player.Player;

class TurnSelectorNextTest {

	@Test
    public void testNext() {
        Player user = new Player("Hugo");
        Player computer = new Player("Robocop");
        
        // Inicializar selector de turnos
        TurnSelector selector = new TurnSelector(user, computer);
        
        // Comprobar que las dos primeras llamadas devuelven jugadores alternados
        assertEquals(user, selector.next());
        assertEquals(computer, selector.next());
    }
}

