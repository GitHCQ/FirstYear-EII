package uo.mp.battleship.service;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

import uo.mp.battleship.model.game.TurnSelector;
import uo.mp.battleship.model.player.Player;

public class TurnSelectorRepeatText {
    
	 @Test
	    public void testRepeat() {
	        // Crear jugadores 
	        Player user = new Player("Hugo");
	        Player computer = new Player("Computer");
	        
	        // Inicializar selector de turnos
	        TurnSelector selector = new TurnSelector(user, computer);
	        
	        // Llamar a next() dos veces para avanzar al segundo jugador
	        selector.next();
	        selector.next();
	        
	        // Guardar el jugador actual
	        Player currentPlayer = selector.next();
	        
	        // Llamar a repeat() para mantener al mismo jugador
	        selector.repeat();
	        
	        // Comprobar que next() devuelve el mismo jugador nuevamente
	        assertEquals(currentPlayer, selector.next());
	    }
}

