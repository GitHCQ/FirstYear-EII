package uo.mp.battleship.model.player;

import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.interaction.ConsoleReader;
import uo.mp.battleship.model.board.Coordinate;

public class HumanPlayer {
	private String name;
    private Board myShips;
    private Board myOpponentShips;
    private ConsoleReader consoleReader;
    
	public HumanPlayer(String name) {
		if(name==null || name.isEmpty() ) {
			this.name="user";
		}
		else {
			this.name=name;
		}
		this.consoleReader = new ConsoleReader();
	}

	public String getName() {
		return this.name;
	}

	public void setMyShips(Board board) {
		this.myShips=board;
	}

	public void setOpponentShips(Board board) {
		this.myOpponentShips=board;
	}

	public boolean shootAt(Coordinate position) {
		return myOpponentShips.shootAt(position);
	}

	public Board getMyShips() {
		return myShips;
	}

	public Board getOpponentShips() {
		return myOpponentShips;
	}

	public boolean hasWon() {
		if(myOpponentShips.isFleetSunk()) {
			return true;
		}
		return false;
	}

	public Coordinate makeChoice() {
		     return this.consoleReader.readCoordinates();
		   }
	}
	
