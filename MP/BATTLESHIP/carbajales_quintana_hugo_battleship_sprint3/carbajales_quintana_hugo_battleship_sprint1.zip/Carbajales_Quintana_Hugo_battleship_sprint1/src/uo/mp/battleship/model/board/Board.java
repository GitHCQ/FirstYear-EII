package uo.mp.battleship.model.board;
import java.util.ArrayList;

public class Board {
	private int [][]  grid;
	
	public Board( int size ) {
		this.grid=new int[size][size];
		this.grid=BoardBuilder.build();
        
	}
	public boolean shootAt(Coordinate position) {
		int row=position.getRow();
		int column=position.getCol();
		if(grid[row][column]!=0 && grid[row][column]!=-10) {
			int valor=Math.abs(grid[row][column]);
			grid[row][column]=-valor;
			return true;
		}
		else {
			grid[row][column]=-10;
			return false;
		}
	}	
	
	public boolean isFleetSunk() {
		for(int i=0;i<grid.length;i++) {
			for(int j=0;j<grid[i].length;j++) {
				if(grid[i][j]>0) {
					return false;
				}
			}
		}
		return true;
	}
	
	
	public int getSize() {
		return grid.length;
	}

	public char[][] getFullStatus() {
		char [][] status=new char[grid.length][grid[0].length];
		for(int i=0;i<grid.length;i++) {
			for(int j=0;j<grid[i].length;j++) {
				status[i][j]=getCharRepresentation(grid[i][j]);
			}
		}
		return status;
	}

	public char[][] getMinimalStatus() {
		char [][] status=new char[grid.length][grid[0].length];
		for(int i=0;i<grid.length;i++) {
			for(int j=0;j<grid[i].length;j++) {
				if(grid[i][j]!=0) {
					status[i][j]=getCharRepresentation(grid[i][j]);
				}
				else {
					status[i][j]=' ';
				}
			}
		}
		return status;
		
	}
	protected int[][] getInnerArray() {
	    int[][] clone = new int[grid.length][];
	    for (int i = 0; i < grid.length; i++) {
	        clone[i] = grid[i].clone();
	    }
	    return clone;
	}
	private char getCharRepresentation(int value) {
	        switch (value) {
	            case 0:
	                return ' '; // Casilla agua
	            case -10:
	                return '\u00F8'; // Disparo perdido
	            case -1:
	            case -2:
	            case -3:
	            case -4:
	                return '*'; // Barco alcanzado
	            case 1:
	                return 'S'; // Submarino
	            case 2:
	                return 'D'; // Destroyer
	            case 3:
	                return 'C'; // Cruiser
	            case 4:
	                return 'B'; // Battleship
	            default:
	                return ' '; // Otros casos
	        }
	    }
	public ArrayList<Coordinate>getNoFiredCoordinates(){
		ArrayList<Coordinate>noFired=new ArrayList<Coordinate>();
		for(int i=0;i<grid.length;i++) {
			for(int j=0;j<grid[i].length;j++) {
				if(grid[i][j]>0) {
					noFired.add(new Coordinate(j,i));
				}
			}
		}
		return noFired;
	}
}
