package uo.mp.battleship.interaction;

import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;


public class ConsoleWriter {

	public void showGameStatus(Board left, Board right, boolean debugMode) {
	    if (debugMode) {
	        // Mostrar encabezados de ambos tableros
	        System.out.print("My ships                         Opponent ships\n");
	        System.out.print("     A  B  C  D  E  F  G  H  I  J           A  B  C  D  E  F  G  H  I  J\n");

	        // Mostrar ambas filas de los tableros
	        for (int i = 0; i < left.getSize(); i++) {
	            System.out.print(String.format("%2d", (i + 1)) + " |");

	            // Mostrar tablero del usuario a la izquierda
	            for (int j = 0; j < left.getSize(); j++) {
	                System.out.print(" " + left.getFullStatus()[i][j] + "|");
	            }

	            System.out.print("      ");  // Espacio entre los tableros

	            // Mostrar número de fila y tablero de la máquina a la derecha
	            System.out.print(String.format("%2d", (i + 1)) + " |");
	            for (int j = 0; j < right.getSize(); j++) {
	                System.out.print(" " + right.getFullStatus()[i][j] + "|");
	            }

	            System.out.println();  // Nueva línea después de cada fila
	        }
	    } else {
	        // Mostrar solo el tablero del oponente (computadora)
	    	 System.out.print("My ships                         Opponent ships\n");
		        System.out.print("     A  B  C  D  E  F  G  H  I  J           A  B  C  D  E  F  G  H  I  J\n");

	        for (int i = 0; i < left.getSize(); i++) {
	            System.out.print(String.format("%2d", (i + 1)) + " |");
	         // Mostrar tablero del usuario a la izquierda
	            for (int j = 0; j < left.getSize(); j++) {
	                System.out.print(" " + left.getFullStatus()[i][j] + "|");
	            }

	            System.out.print("      ");  // Espacio entre los tableros
	            System.out.print(String.format("%2d", (i + 1)) + " |");
	            // Mostrar tablero de la máquina con disparos del jugador
	            for (int j = 0; j < right.getSize(); j++) {
	                if (right.getFullStatus()[i][j] == '*') {
	                    System.out.print(" " + right.getFullStatus()[i][j] + "|");
	                } else if (right.getFullStatus()[i][j] == '\u00F8') {
	                    System.out.print(" " + right.getFullStatus()[i][j] + "|");
	                } else {
	                    System.out.print(" " + " " + "|");
	                }
	            }

	            System.out.println();  // Nueva línea después de cada fila
	        }
	    }
	}

	/*
	 * Expected message 
	 * 		The winner is ... winner name
	 */
	public void showWinner(String winner) {
		System.out.print("The winner is..."+winner);
	}

	/*
	 * Expected message
	 * 		The game is over!!
	 */
	public void showGameOver() {
		System.out.print("The game is over!!");
	}
	
	/*
	 * Expected message
	 * 		Now the turn is for the player player name
	 */
	public void showTurn(String playerName) {
		System.out.println("Now the turn is for the player "+playerName);
	}

	/*
	 * Expected message
	 * 		Shoot at user-friendly
	 */
	public void showShootingAt(Coordinate position) {
		char columnChar = (char) ('A' + position.getCol()); 
	    int rowNumber = position.getRow() + 1; 

	    System.out.println("Shot at " + columnChar + rowNumber);

	}

	/*
	 * Expected message
	 * 		Depending on the shot result:
	 * 		MISS, HIT!! (sprint 1)
	 * 		MISS, HIT!!. Continue, HIT AND SUNK!!. Continue (from sprint 2 on)
	 */
	public void showShotMessage(boolean damage) {
				if(damage) {
					System.out.println("HIT!");
				}
				else {
					System.out.println("MISS");
				}
	}
}