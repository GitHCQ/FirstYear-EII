package uo.mp.battleship.model.board;
public class Coordinate {
	private int x;
	private int y;
		
	public Coordinate(int col, int row) {
		this.x=col;
		this.y=row;
	}

	public int getCol() {
		return x;
	}

	public int getRow() {
		return y;
	}
	
	@Override
	public String toString() {
		return "Coordenada [ x = " + x + ", y = " + y + " ]";
	}

	public String toUserString() {
		 char columnChar = (char) ('A' + x); 
	     return columnChar + "-" + (y+1);
	    }

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Coordinate other = (Coordinate) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}
	
}
