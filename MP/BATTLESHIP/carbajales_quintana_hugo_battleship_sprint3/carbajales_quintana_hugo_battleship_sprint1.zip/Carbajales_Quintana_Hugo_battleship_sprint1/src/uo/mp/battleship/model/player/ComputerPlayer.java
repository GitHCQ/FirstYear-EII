package uo.mp.battleship.model.player;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import java.util.Random;

public class ComputerPlayer {
	private String name;
    private Board myShips;
    private Board myOpponentShips;
    
	public ComputerPlayer(String name) {
		if(name==null || name.isEmpty() ) {
			this.name="computer";
		}
		else {
			this.name=name;
		}
	}

	public String getName() {
		return this.name;
	}

	public void setMyShips(Board board) {
		this.myShips=board;
	}

	public void setOpponentShips(Board board) {
		this.myOpponentShips=board;
	}

	public boolean shootAt(Coordinate position) {
		return myOpponentShips.shootAt(position);
	}

	public Board getMyShips() {
		return myShips;
	}

	public Board getOpponentShips() {
		return myOpponentShips;
	}

	public boolean hasWon() {
		if(this.myOpponentShips.isFleetSunk()) {
			return true;
		}
		return false;
	}
	
	public Coordinate makeChoice() {
		Random random = new Random();
		int index=random.nextInt(myOpponentShips.getNoFiredCoordinates().size());
		return myOpponentShips.getNoFiredCoordinates().get(index);
	  }
	}
