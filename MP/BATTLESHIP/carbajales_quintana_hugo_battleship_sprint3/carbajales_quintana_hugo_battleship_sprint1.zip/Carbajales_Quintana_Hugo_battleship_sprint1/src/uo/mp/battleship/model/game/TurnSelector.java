package uo.mp.battleship.model.game;

class TurnSelector {
	private int currentPlayer;
	TurnSelector() {
		this.currentPlayer = 1;;
	}
	
	int next() {
		currentPlayer = 1 - currentPlayer;
		return currentPlayer;
	}
}

