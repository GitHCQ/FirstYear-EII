package uo.mp.battleship.model.game;

import uo.mp.battleship.interaction.ConsoleReader;
import uo.mp.battleship.interaction.ConsoleWriter;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.player.ComputerPlayer;
import uo.mp.battleship.model.player.HumanPlayer;

public class Game {
	private HumanPlayer humanPlayer;
    private ComputerPlayer computerPlayer;
    private TurnSelector currentPlayer;
    private ConsoleWriter presenter;
    private Board HumanBoard;
    private Board ComputerBoard;
	private boolean debugMode=false;
	private ConsoleReader consoleReader;
	
	public Game(HumanPlayer leftPlayer, ComputerPlayer rightPlayer) {
		// Asigno los jugadores
        this.humanPlayer = leftPlayer;
        this.computerPlayer = rightPlayer;

        // Creo dos tableros de dimensiones 10x10
        this.HumanBoard = new Board(10);
        this.ComputerBoard = new Board(10);

        // Asigno los tableros a cada jugador
        this.humanPlayer.setMyShips(HumanBoard);
        this.humanPlayer.setOpponentShips(ComputerBoard);

        this.computerPlayer.setMyShips(ComputerBoard);
        this.computerPlayer.setOpponentShips(HumanBoard);
        this.presenter=new ConsoleWriter();
        this.consoleReader=new ConsoleReader();
        this.currentPlayer = new TurnSelector();
    }
	
	public void setDebugMode ( boolean gameMode ) {
		debugMode=gameMode;
	}

	public void play() {
	    while (!humanPlayer.hasWon() && !computerPlayer.hasWon()) {
	        // Alternar el turno utilizando el TurnSelector

	        // Se muestran los tableros
	        presenter.showGameStatus(HumanBoard, ComputerBoard, debugMode);
	        // Turno del humano
	        presenter.showTurn(humanPlayer.getName());
	        Coordinate posHumano = humanPlayer.makeChoice();
	        posHumano = new Coordinate(posHumano.getCol(), posHumano.getRow());
	        presenter.showShootingAt(posHumano);
	        boolean disparo = humanPlayer.shootAt(posHumano);
	        presenter.showShotMessage(disparo);
	        if (humanPlayer.hasWon()) {
	            presenter.showWinner(humanPlayer.getName());
	            break;
	            }
	         // Turno de la computadora
	         presenter.showTurn(computerPlayer.getName());
	         Coordinate posMaquina = new Coordinate(computerPlayer.makeChoice().getCol(), computerPlayer.makeChoice().getRow());
	         presenter.showShootingAt(posMaquina);
	         boolean disparoMaquina = computerPlayer.shootAt(posMaquina);
	         presenter.showShotMessage(disparoMaquina);
	         //currentPlayerIndex=currentPlayer.next();	

	         if (computerPlayer.hasWon()) {
	        	 presenter.showWinner(computerPlayer.getName());
	        	 break;
	            }
	        }
	    }
	}