package uo.mp.lab06.greenhouse.actuators.doors;

public interface VentilationDevice {
	public String open();
	public String close();
	public boolean isOpened();
}
