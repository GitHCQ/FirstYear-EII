package uo.mp.lab06.greenhouse.controllers.devicescanner;

public interface Checkable {
	public boolean check();

}
