package uo.mp.greenhouse.actuators.irriegator;

public enum LevelOfWater {
	OFF,
	LOW,
	MEDIUM,
	HIGH,

}
