package uo.mp.util.collections.impl;

import java.util.Iterator;
import java.util.Objects;

public class LinkedList extends AbstractList<Object> {
    Node head;
    private class Node {
        Object element;
        Node next;

        Node(Object element, Node node) {
            this.element = element;
            this.next = node;
        }
    }

    public LinkedList() {
        this.numberOfElements = 0;
        this.head = null;
    }

    @Override
    public int size() {
        return numberOfElements;
    }

    private void checkIndex(int index) {
        if (index < 0 || index >= this.size()) {
            throw new IndexOutOfBoundsException("Index out of bounds: " + index);
        }
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public boolean contains(Object o) {
        Node current = head;
        while (current != null) {
            if (current.element.equals(o)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    @Override
    public boolean add(Object element) {
        add(size(), element);
        return true;
    }

    @Override
    public boolean remove(Object o) {
        if (head == null) {
            return false;
        }
        if (head.element.equals(o)) {
            head = head.next;
            numberOfElements--;
            return true;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.element.equals(o)) {
                current.next = current.next.next;
                numberOfElements--;
                return true;
            }
            current = current.next;
        }
        return false;
    }
   

    @Override
	public int hashCode() {
		return Objects.hash(head);
	}

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        LinkedList other = (LinkedList) obj;
        
        // Compara el tamaño de las listas
        if (size() != other.size())
            return false;
        
        // Compara cada nodo de las listas
        Node currentThis = head;
        Node currentOther = other.head;
        while (currentThis != null && currentOther != null) {
            // Utiliza el método equals de Node para comparar los datos contenidos en los nodos
            if (!currentThis.equals(currentOther))
                return false;
            currentThis = currentThis.next;
            currentOther = currentOther.next;
        }
        
        // Si ambos punteros llegan al final de la lista al mismo tiempo, las listas son iguales
        return currentThis == null && currentOther == null;
    }



	@Override
	public void clear() {
	    head = null;
	    numberOfElements = 0;
	}

    @Override
    public Object get(int index) {
        checkIndex(index);
        Node node = getNode(index);
        return node.element;
    }

    private Node getNode(int index) {
        checkIndex(index);
        int pos = 0;
        Node node = head;
        while (pos < index) {
            node = node.next;
            pos += 1;
        }
        return node;
    }

    @Override
    public Object set(int index, Object element) {
        checkIndex(index);
        Node node = getNode(index);
        Object oldElement = node.element;
        node.element = element;
        return oldElement;
    }

    @Override
    public void add(int index, Object element) {
        if (index < 0 || index > size()) {
            throw new IndexOutOfBoundsException("Index out of bounds: " + index);
        }
        if (element == null) {
            throw new IllegalArgumentException("Cannot add null elements to the list");
        }
        if (index == 0) {
            head = new Node(element, head);
        } else {
            Node previous = getNode(index - 1);
            previous.next = new Node(element, previous.next);
        }
        numberOfElements++;
    }


    @Override
    public Object remove(int index) {
        checkIndex(index);
        Object removedElement;
        if (index == 0) {
            removedElement = head.element;
            head = head.next;
        } else {
            Node previus = getNode(index - 1);
            removedElement = previus.next.element;
            previus.next = previus.next.next;
        }
        numberOfElements--;
        return removedElement;
    }

    @Override
    public int indexOf(Object o) {
        Node current = head;
        int index = 0;
        while (current != null) {
            if (current.element.equals(o)) {
                return index;
            }
            current = current.next;
            index++;
        }
        return -1;
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Node current = head;
        while (current != null) {
            sb.append(current.element);
            if (current.next != null) {
                sb.append(", ");
            }
            current = current.next; // Avanzar al siguiente nodo
        }
        sb.append("]");
        return sb.toString();
    }

    @Override
    public Iterator<Object> iterator() {
        return new LinkedListIterator();
    }

    private class LinkedListIterator implements Iterator<Object> {
        Node next;
        int nextIndex;
        Node lastReturned;

        private LinkedListIterator() {
            next = head;
            nextIndex = 0;
            lastReturned = null;
        }

        @Override
        public boolean hasNext() {
            return next != null;
        }

        @Override
        public Object next() {
            lastReturned = next;
            next = next.next;
            nextIndex++;
            return lastReturned.element;
        }

        @Override
        public void remove() {
            if (lastReturned == null) {
                throw new IllegalStateException("No es posible eliminar el elemento");
            }
            LinkedList.this.remove(nextIndex - 1);
            nextIndex--;
            lastReturned = null;
        }
    }
}
