package uo.mp.lab04.dome;

import uo.mp.lab04.dome.ui.MediaPlayer;

public class Main {

    public static void main(String[] args) {
	new MediaPlayer().run();
    }

}
