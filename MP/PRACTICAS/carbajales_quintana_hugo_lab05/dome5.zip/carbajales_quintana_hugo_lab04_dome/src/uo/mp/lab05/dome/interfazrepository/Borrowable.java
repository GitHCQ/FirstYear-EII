package uo.mp.lab05.dome.interfazrepository;

public interface Borrowable {
    void giveback();

    void borrow();

    boolean isAvaileable();

}
