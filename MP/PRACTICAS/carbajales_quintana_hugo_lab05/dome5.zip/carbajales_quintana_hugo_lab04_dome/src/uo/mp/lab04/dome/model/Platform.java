package uo.mp.lab04.dome.model;

public enum Platform {
    XBOX, PLAYSTATION, NINTENDO
}
