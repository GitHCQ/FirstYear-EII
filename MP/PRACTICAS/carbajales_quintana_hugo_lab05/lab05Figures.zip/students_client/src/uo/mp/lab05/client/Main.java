package uo.mp.lab05.client;

import uo.mp.lab05.client.ui.Client;

public class Main {
	
	public static void main(String[] args) {
		new Client().run();
	}

	
}
