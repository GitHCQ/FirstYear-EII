/**
 * 
 */
package uo.mp.lab05.drawing.interfacerepository;

import java.io.PrintStream;

/**
 * @author tete morente
 *
 */
public interface Drawable {
	public void draw(PrintStream out);
}
