package uo.mp.lab03.SocialApp;

import uo.mp.lab03.SocialApp.ui.NetworkApp;

public class Main {
	 public static void main(String[] args) {
			new NetworkApp().SimulateClient();
		    }

}
