package uo.mp.lab03.dome;

import uo.mp.lab03.dome.ui.MediaPlayer;

public class Main {

    public static void main(String[] args) {
	new MediaPlayer().run();
    }

}
