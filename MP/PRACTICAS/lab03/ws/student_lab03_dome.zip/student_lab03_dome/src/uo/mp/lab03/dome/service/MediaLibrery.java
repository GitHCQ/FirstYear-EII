/**
 * 
 */
package uo.mp.lab03.dome.service;

import java.io.PrintStream;
import java.util.ArrayList;

import uo.mp.lab03.dome.model.Item;
import uo.mp.util.check.ArgumentChecks;

/**
 * @author UO300798
 *
 */
public class MediaLibrery {
    private ArrayList<Item> items = new ArrayList<>();

//    public MediaLibrery() {
//	items = new ArrayList<>();
//	
//    }

    /**
     * Añade un item a la lista de items
     * Si recibe null salta excepción
     * 
     * @param item a añadir
     * @throws IllegarArgumentException si recibe null
     */
    public void add(Item theItem) {
	ArgumentChecks.isNotNull(theItem);
	items.add(theItem);
    }

    protected ArrayList<Item> getItems() {
	return new ArrayList<>(items);

    }

    /**
     * Devuelve el numero de items con propietario
     * 
     * @return numero de items con propietario
     */
    public int numberOfItemsOwned() {
	int numberOfItems = 0;
	for (Item itemToCheck : items) {
	    if (itemToCheck.getOwn()) {
		numberOfItems++;
	    }
	}
	return numberOfItems;
    }

    /**
     * Imprime en el objeto out los datos de todos los items de la libreria
     * 
     * @param out, objeto de tipo PrintStream en el que se imprimen los datos
     * 
     */
    public void list(PrintStream out) {
	for (Item itemToPrint : items) {
	    itemToPrint.print(out);
	}
    }

}
